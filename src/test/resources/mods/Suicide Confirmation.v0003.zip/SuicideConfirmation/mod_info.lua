name = "Suicide Confirmation"
version = 3
copyright = "Moritz"
description = "Asks for confirmation before self destructing units"
author = "Moritz"
icon = "/mods/SuicideConfirmation/ctrlkconfirm.png"
url = "http://www.anacondas.com.br"
uid = "BB236B78-CB23-4E78-8CD7-BA55AE987545"

exclusive = false
ui_only = true
