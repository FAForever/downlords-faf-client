do
	table.insert(options.ui.items,
				{
					title = "Confirm Self Destruct",
					key = "ui_SelfDestruct",
					type = 'toggle',
					default = true,
					custom = {
						states = {
							{text = "<LOC _Off>", key = false },
							{text = "<LOC _On>", key = true },
						},
					},
				})
end
